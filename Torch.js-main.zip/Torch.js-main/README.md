# Torch.js
A javascript PyTorch recreation.

## Information to know
- All manipulatable variables are detailed in editable.js
- Documentation and manual coming soon
- Torch.js cannot be downloaded sans editable.js, but the file can be forked and edited for your own projects
- Currently under development: trainingfunctions.js (trainGPT), loadshit.js (loadshitGPT), and networkcalc.js (runGPT)
- Need to fix overall
  1. trainGen
  2. runGen
  3. loadshitGen
  4. trainGPT
  5. loadshitGPT
  6. runGPT
